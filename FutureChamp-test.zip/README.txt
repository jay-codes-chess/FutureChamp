FutureChamp Test Release
Build date: 2026-02-15
Features:
- Correct move generation (perft verified)
- Aspiration windows (reduces nodes dramatically)
- LMR pruning
- Transposition table
- HumanSelect mode

Known limitations:
- Evaluation still under tuning
- Strength expected approx 1800-2100 Elo
- Known issue: occasional illegal move bug in selfplay
